import { createContext } from "react";

export const functionsContext=createContext();
export const messagesContext=createContext();